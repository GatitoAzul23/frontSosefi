import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

//listado de componentes en la navegación

import { InicioSesionComponent } from './inicio-sesion/inicio-sesion.component';
import { AsesoriasComponent } from './asesorias/asesorias.component';
import { AsesoriasFormComponent } from './asesorias-form/asesorias-form.component';
import { InicioComponent } from './inicio/inicio.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RegistroCitaComponent } from './registro-cita/registro-cita.component';
import { ProductosComponent } from './productos/productos.component';
import { ProductoDetalleComponent } from './producto-detalle/producto-detalle.component';
import { EmpleadosComponent } from './empleados/empleados.component';
import { EmpleadoDetalleComponent } from './empleado-detalle/empleado-detalle.component';
import { ProductospubComponent } from './productospub/productospub.component';
import { PerfilComponent } from './perfil/perfil.component';
import { ServiciosFormComponent } from './servicios-form/servicios-form.component';
import { SensorComponent } from './sensor/sensor.component';
import { CobroComponent } from './cobro/cobro.component';
import { ServicioInactivoComponent } from './servicio-inactivo/servicio-inactivo.component';
import { CotizacionRegistroComponent } from './cotizacion-registro/cotizacion-registro.component';
import { CotizacionComponent } from './cotizacion/cotizacion.component';
import { ActualizarServicioComponent } from './actualizar-servicio/actualizar-servicio.component';

//Listado de guardias
import { loginGuard } from './guardias/login.guard';

const routes: Routes = [
  {path: "login", component:InicioSesionComponent},
  {path: "inicio", component:InicioComponent},
  {path: "asesorias", component:AsesoriasComponent},
  {path: "asesoriasForm", component:AsesoriasFormComponent},
  {path: "dashboard", component : DashboardComponent},
  {path: "citas/agendar", component:RegistroCitaComponent, canActivate:[loginGuard]},
  {path: "productos", component: ProductosComponent, canActivate:[loginGuard]},
  {path: 'productos/codigo/:codigo', component: ProductoDetalleComponent, canActivate:[loginGuard]},
  {path: "empleados", component: EmpleadosComponent, canActivate:[loginGuard]},
  {path: 'empleados/detalle/:email', component:EmpleadoDetalleComponent, canActivate:[loginGuard]},
  {path: "productos/catalogo", component: ProductospubComponent},
  {path: "perfil", component: PerfilComponent, canActivate:[loginGuard]},
  {path: "serviciosForm", component: ServiciosFormComponent},
  {path: "sensor", component:SensorComponent, canActivate:[loginGuard]},
  {path: "cobros", component:CobroComponent, canActivate:[loginGuard]},
  {path: "servInac", component:ServicioInactivoComponent, canActivate:[loginGuard]},
  {path: "cotizar/:folio", component:CotizacionRegistroComponent, canActivate:[loginGuard]},
  {path: "cotizacion/:folio", component:CotizacionComponent, canActivate:[loginGuard]},
  {path: "agendar", component:ActualizarServicioComponent, canActivate:[loginGuard]},
  {path: "**", redirectTo: "/inicio"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
