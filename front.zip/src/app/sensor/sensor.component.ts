import { Component, OnInit } from '@angular/core';
import { SensorService } from '../servicios/sensor.service';
import {Chart, registerables} from 'node_modules/chart.js';
Chart.register(...registerables);
@Component({
  selector: 'app-sensor',
  templateUrl: './sensor.component.html',
  styleUrls: ['./sensor.component.css']
})
export class SensorComponent implements OnInit{

  sensor ={
    fecha:"",
    hora:"",
    lectura:""
  }
  info : any;
  valores:any;
  infolavel:any[]=[];
  valordata:any[]=[];
  fechadata:any[]=[];
  intervalo: any;
  
  ngOnInit(): void {
    this.ServicioSensor.consultar().subscribe(
      res=>{
        this.info =res;
        if(this.info!=null){
          for(let i=0; i<this.info.length; i++){
            //console.log(this.info[0])
            this.infolavel.push(this.info[i].hora);
            this.valordata.push(this.info[i].lectura);
            this.fechadata.push(this.info[i].fecha);
          }
          this.RenderChart(this.infolavel, this.valordata, this.fechadata);
        }
      }
    );
    this.consultar();
    
  }

  constructor(private ServicioSensor: SensorService){}

  iniciarLectura(){
    this.ServicioSensor.activarLectura().subscribe(
      (res)=>{
        this.sensor.lectura = res.valorSensor;
      },
      (err)=>{
        console.log(err);
      }
    );
  }

  detenerLectura(){
    this.ServicioSensor.detenerLectura().subscribe(
      (res)=>{
        this.pausa();
        alert("Lectura detenida");
      },
      (err)=>{
        console.log(err);
      }
    );
  }

  consultar(){
    this.valores = this.ServicioSensor.consultar();
  }

  guardarLectura(){
    this.ServicioSensor.guardarLectura(this.sensor).subscribe(
      (res)=>{
        alert("Lectura registrada");
      },
      (err)=>{
        alert("Error al registrar la lectura");
      }
    );
  }

  starTimer(){
    this.intervalo = setInterval(
      ()=>{
        this.iniciarLectura();
      },5000); //5*60*1000 = 300000 miliseg ejecturar cada 5 minutos
  }

  pausa(){
    clearInterval(this.intervalo);
  }

  RenderChart(infolavel:any, valordata:any, fechadata:any){
    const myChart = new Chart("piechart", {
      type: 'bar',
      data: {
        labels: fechadata,
        datasets: [{
          label: 'Partes por millon',
          data: valordata,
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
  }
}
