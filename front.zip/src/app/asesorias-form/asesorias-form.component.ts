import { Component, OnInit } from '@angular/core';
import { ProductosService } from '../servicios/productos.service';
import { InicioSesionService } from '../servicios/inicio-sesion.service';
import { ProductoDataService } from '../servicios/producto-data.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-asesorias-form',
  templateUrl: './asesorias-form.component.html',
  styleUrls: ['./asesorias-form.component.css']
})
export class AsesoriasFormComponent implements OnInit{

  selectedProduct: string = '';

  empleado={
    nombre: "",
    apellido_paterno: "",
    apellido_materno: "",
    email:"",
    rfc : "",
    telefono: "",
    nss: "",
    puesto: "",
    sueldo: "",
    estado: "Activo",
    fecha_nac: "" 
  }
  usuario ={
    password:"",
    password_ant:"",
    email: localStorage.getItem("email")
  }

  constructor(private servicioLogin: InicioSesionService, private ProductoData: ProductoDataService){}

  ngOnInit(): void {
    this.ProductoData.selectedProduct$.subscribe(productName => {
      this.selectedProduct = productName;
    });
  }


  cambiarContra(){
    this.servicioLogin.cambiarContra(this.usuario).subscribe(
      res=>{
          Swal.fire({
          title: 'Se cambió la contraseña',
          icon: 'success',
          timer: 2000,
        });
        this.limpiarCampos();
      },
      err=>{
        Swal.fire({
        title: err.error.error[0].msg,
        icon: 'error',
        timer: 2000,
        });
        // alert(err.error.error[0].msg);
      }
    );
  }

  limpiarCampos(){
    this.usuario.password ="";
    this.usuario.password_ant ="";
  }
}
