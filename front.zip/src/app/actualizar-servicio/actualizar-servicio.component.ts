import { Component } from '@angular/core';

@Component({
  selector: 'app-actualizar-servicio',
  templateUrl: './actualizar-servicio.component.html',
  styleUrls: ['./actualizar-servicio.component.css']
})
export class ActualizarServicioComponent {

  servicio={
    idServicio:"",
    nombreCliente:"",
    apellidoCliente:"",
    correo:"",
    fecha:"",
    hora:"",
    lugar:"",
    telefono:"",
    idCotizacion:"",
  }
}
